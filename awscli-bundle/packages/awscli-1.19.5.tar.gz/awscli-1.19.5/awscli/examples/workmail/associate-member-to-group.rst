**To add a member to a group**

The following ``associate-member-to-group`` command adds the specified member to a group. ::

    aws workmail associate-member-to-group \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --group-id S-1-1-11-1122222222-2222233333-3333334444-4444 \
        --member-id S-1-1-11-1111111111-2222222222-3333333333-3333

This command produces no output.
